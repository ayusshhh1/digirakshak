from pyngrok import ngrok

NGROK_AUTH_TOKEN = "2wtRJ14gQgY9VyyJdLOSYClqNfJ_51KLc3YZFw2ox5khgi3RH"


def setup_ngrok(port=5000):
    if NGROK_AUTH_TOKEN:
        ngrok.set_auth_token(NGROK_AUTH_TOKEN)
        public_url = ngrok.connect(port)
        print(f" * ngrok tunnel '{public_url}' -> 'http://127.0.0.1:{port}'")
    else:
        print("NGROK_AUTH_TOKEN not set in environment.")

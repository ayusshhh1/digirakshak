from flask import Flask
from flask_cors import CORS

app = Flask(__name__)
CORS(app)

from app.routes.classifier import *
from app.routes.url_scan import *

import base64, requests

HEADERS = {
    "x-apikey": "f8b7e357907287e1019d5494b5eb2ddf60ab3be5dc20ec8cca2d775eb2abc0e3"
}


def scan_url_with_virustotal(url):
    url_id = base64.urlsafe_b64encode(url.encode()).decode().strip("=")
    report_url = f"https://www.virustotal.com/api/v3/urls/{url_id}"
    response = requests.get(report_url, headers=HEADERS)

    if response.status_code == 200:
        data = response.json()
        stats = data["data"]["attributes"]["last_analysis_stats"]

        verdict = (
            "unsafe" if stats["malicious"] > 0 or stats["suspicious"] > 0 else "safe"
        )

        return {"url": url, **stats, "verdict": verdict}
    else:
        return {"error": "Failed to fetch report", "details": response.text}

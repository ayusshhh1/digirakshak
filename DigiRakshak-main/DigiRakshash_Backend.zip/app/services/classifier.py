import os
import pickle
from flask import jsonify

# Load vectorizer and model
vectorizer, model = None, None
try:
    with open("app/assets/vectorizer.pkl", "rb") as vec_file:
        vectorizer = pickle.load(vec_file)
    with open("app/assets/model.pkl", "rb") as model_file:
        model = pickle.load(model_file)
except FileNotFoundError as e:
    print(f"Error loading model assets: {e}")

def predict_spam(request):
    if not vectorizer or not model:
        return jsonify({"error": "Model or vectorizer not loaded."}), 500

    data = request.get_json()
    if not data or "message" not in data:
        return jsonify({"error": 'Missing "message" in request body'}), 400

    try:
        message = data["message"]
        message_vector = vectorizer.transform([message])
        prediction = model.predict(message_vector)[0]
        result = "Spam" if prediction == 1 else "Not Spam"
        return jsonify({"input": message, "prediction": result})
    except Exception as e:
        return jsonify({"error": str(e)}), 500

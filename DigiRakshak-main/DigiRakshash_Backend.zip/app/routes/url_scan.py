from flask import request, jsonify
from app import app
from app.services.url_scan import scan_url_with_virustotal

@app.route("/api/url-scan", methods=["POST"])
def url_scan():
    data = request.get_json()
    url = data.get("url")
    if not url:
        return jsonify({"error": "URL is required"}), 400

    result = scan_url_with_virustotal(url)
    return jsonify(result), (200 if "error" not in result else 500)

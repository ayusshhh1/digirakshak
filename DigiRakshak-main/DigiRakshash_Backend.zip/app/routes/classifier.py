from flask import request
from app import app
from app.services.classifier import predict_spam

@app.route("/api/predict", methods=["POST"])
def predict():
    return predict_spam(request)
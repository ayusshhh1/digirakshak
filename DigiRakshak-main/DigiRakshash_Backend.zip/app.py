from flask import Flask, request, jsonify
from flask_cors import CORS
import pickle
import requests
import base64
from pyngrok import ngrok

app = Flask(__name__)
CORS(app)  # Enable CORS for all routes

# Load vectorizer
try:
    with open("vectorizer.pkl", "rb") as vec_file:
        vectorizer = pickle.load(vec_file)
except FileNotFoundError:
    print("Error: vectorizer.pkl not found. Ensure it is in the correct directory.")
    vectorizer = None

# Load model
try:
    with open("model.pkl", "rb") as model_file:
        model = pickle.load(model_file)
except FileNotFoundError:
    print("Error: model.pkl not found. Ensure it is in the correct directory.")
    model = None

# VirusTotal API key and headers
API_KEY = "f8b7e357907287e1019d5494b5eb2ddf60ab3be5dc20ec8cca2d775eb2abc0e3"
HEADERS = {"x-apikey": API_KEY}

# Home route
@app.route("/")
def home():
    return jsonify({
        "message": "Welcome to the Multi-Utility API. Use POST /predict for spam classification or /api/url-scan for URL scanning."
    })

# SMS Spam Classifier Route
@app.route("/predict", methods=["POST"])
def predict():
    if vectorizer is None or model is None:
        return jsonify({"error": "Model or vectorizer not loaded. Check server logs."}), 500

    data = request.get_json()
    if not data or "message" not in data:
        return jsonify({"error": 'Missing "message" in request body'}), 400

    message = data["message"]
    try:
        message_vector = vectorizer.transform([message])
        prediction = model.predict(message_vector)[0]
        result = "Spam" if prediction == 1 else "Not Spam"

        return jsonify({"input": message, "prediction": result})
    except Exception as e:
        print(f"Error during prediction: {e}")
        return jsonify({"error": f"Error during prediction: {e}"}), 500

# VirusTotal URL Scan logic
def scan_url_with_virustotal(url):
    url_id = base64.urlsafe_b64encode(url.encode()).decode().strip("=")
    report_url = f"https://www.virustotal.com/api/v3/urls/{url_id}"
    response = requests.get(report_url, headers=HEADERS)

    if response.status_code == 200:
        data = response.json()
        stats = data["data"]["attributes"]["last_analysis_stats"]

        print(f"\n🔗 URL Checked: {url}")
        print(f"✔️ Harmless: {stats['harmless']}")
        print(f"⚠️ Suspicious: {stats['suspicious']}")
        print(f"🚫 Malicious: {stats['malicious']}")
        print(f"🧪 Undetected: {stats['undetected']}")

        verdict = "safe"
        if stats["malicious"] > 0 or stats["suspicious"] > 0:
            verdict = "unsafe"

        return {
            "url": url,
            "harmless": stats["harmless"],
            "suspicious": stats["suspicious"],
            "malicious": stats["malicious"],
            "undetected": stats["undetected"],
            "verdict": verdict
        }
    else:
        return {"error": "Failed to fetch report", "details": response.text}

# URL Scan Route
@app.route("/api/url-scan", methods=["POST"])
def url_scan():
    data = request.get_json()
    url = data.get("url")

    if not url:
        return jsonify({"error": "URL is required"}), 400

    result = scan_url_with_virustotal(url)
    status_code = 200 if "error" not in result else 500
    return jsonify(result), status_code

# Start app and ngrok tunnel
if __name__ == "__main__":
    ngrok.set_auth_token("2wtRJ14gQgY9VyyJdLOSYClqNfJ_51KLc3YZFw2ox5khgi3RH")
    public_url = ngrok.connect(5000)
    print(f" * ngrok tunnel available at: {public_url}")
    app.run(debug=True, host="0.0.0.0", port=5000)

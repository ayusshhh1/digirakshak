from app import app
from app.utils.ngrok import setup_ngrok

if __name__ == "__main__":
    # setup_ngrok(port=5000)
    app.run(debug=True, host="0.0.0.0", port=5000)

import React from 'react'
import Navbar from './components/Navbar';
import Home from './pages/Home';
import { Routes, Route, BrowserRouter } from 'react-router-dom';
import About from './pages/About';
import Services from './pages/Services';
import Test from './pages/Test';

export default function App() {
  return (
    <div>
<BrowserRouter>
    <Navbar/>
    <Routes>
      <Route path='/' element={<Home/>}/>
      <Route path='/About' element={<About/>}/>
      <Route path='/Services' element={<Services/>}/>
      <Route path='/Test' element={<Test/>}/>
    </Routes>

</BrowserRouter>
    </div>
  )
}

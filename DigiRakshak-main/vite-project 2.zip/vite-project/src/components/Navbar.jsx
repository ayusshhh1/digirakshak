import React, { useEffect, useState, useCallback } from 'react';
import './navbar.css';
import { Link, useLocation } from 'react-router-dom';

export default function Navbar() {
  const location = useLocation();
  const isTestPage = location.pathname === '/Test';
  const [displayText, setDisplayText] = useState('DIGIरक्षक'); // Initial text in Hindi
  const textOptions = ['DIGI रक्षक', 'DIGI Rakshak']; // Hindi and English texts
  const [textIndex, setTextIndex] = useState(0);


  const updateText = useCallback(() => {
    setTextIndex((prevIndex) => (prevIndex + 1) % textOptions.length);
  }, [textOptions]);

  useEffect(() => {
    const intervalInMilliseconds = 1000; // Change text every 2 seconds (adjust as needed)

    const intervalId = setInterval(updateText, intervalInMilliseconds);


    return () => clearInterval(intervalId);
  }, [updateText]); // Depend on updateText for stability

  useEffect(() => {
    setDisplayText(textOptions[textIndex]);
  }, [textIndex, textOptions]);

  return (
    <div>
      <nav
        style={{
          backgroundColor: isTestPage ? '#868383' : '#46464673',
          color: isTestPage ? '#0f0f0f' : '#ffffff',
          padding: '10px',
        }}
      >
        <Link to="/">
          <div className="logo">
            <img
src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAR8AAACwCAMAAAABtJrwAAABoVBMVEX////+79n++fH8/f/s9P/4+//x9//+9N7+8Nq9ga3///XXus72+v/z+P/r8///997BirPBiKzu3+uYEXr+3cPwwsv//Pr8tC/8rC//bkL/oHvr2OehQYH9tKT5///+9OX+eTL/cjL/lHX37/f/dTL+9ur9pzD9ojD9mjDll5b8qy/me2iPAHH+lTD+izH+fjL/6+X/XR7/Yin/qI/+t4v/zcD/g13/xbb+5c7+yKz+1Lr8u3TsdkH06fH/bDP/d0n/u5z+m27/3tb/nXn/noXlh3/2iSW1cqa+fJ3rzcjsc0H/mSP34tPIj6fsr7b/hWCoVZP/sI/+eB7/VQD/sZz23uTsjk/8rgDopKLojWrqkWbxlzT0rHjwnE/9w3rtkELvydfpg1PshjTojnfnkovsgkHngFjln6zpdCjlj5Xlmqfns8HlZTb9rWX+y6PWko2BAF+iRILUo7LOocOcLXy0aJPjwMDmdWfodVjqm4XkeXjwdzn8hxnLnLjmYlPlf37YdY6JAHe6UoPBVGn7bQztWD7qZ17wUy7ySh3pVEjmXVnjviJVAAARJUlEQVR4nO2djVvaWL7HkyAk1aAOKIIIKCi+oZIwINghoLVax474xra9t/cO2hfX4szurHSccTvO7p3W7ty/+p6XhJy8gHbutvZgvj4PaJJzzPnwezt5g2EcOXLkyJEjR44cOXLkyJEjR44cOXLkyFEnKJ296T34rBUo7a3c9D58ziplVvbSN70Tn6/iFYZZlLib3o3PVZkSfI0ogZvekc9TGphM7oZ35PPUoqRFnnj8Rnfkc1OAm4gJfIEIzJVlXohNcI6fMQGAhgXilyQisQdKOzxcKsRuNSMOs4F48tIiuSaglHl1FWB0U/t3o+JibFNCXo4Y16blAq+vn7h1VjQhsCSeUsa8wYq0xJObTNzEXt6QAhMsKT6vWPBYAAEj+vQ7eiMKxFgjngF53267FblsBHQ73MxoOyxI7GRorj7Wf0+HMrxgIvTp9/fTimNNeIRhmUjsxT89IgAFKrm8yYSEjk5mAZM5AN8KVQincR8MDQUJQEwEpDFTm1jnOtmEmQ6/I5F53fVkCCi5RSxaCcXzZkKdakKmuCzwS6ESebAH4xkamhwkFgZWpR3B5GSxT73nn0Kcmc5AxVgzu588GrIBxKzklAJvJCR0no9NmOjkM3urhlEm/mOoKYOLMUxWzi3xRi/rNB+LGeDw+XtSvOlaLvhS/RMiE/xP/DbtVteglcy+VCoIBkKdlenJuRbPLsWl1TQcOvgBggwGpzCXn5/+F/rl0ZMio66EL0wgElLKedKIOigINdM6sBx+YFiRM2k8eFWMOJ1EVGammf9OfIt97NsauQ3oJZuT4gVWR9QxgAIIDWTDFgCcOKwHSTpM7QBH5sktJnCXSRyoURr4mGEzJh0pSZVCHvQkCJ0DKMBDsQOF4ZxcWs0GDHDAuN2Pp4aCQEOHIG0BPoz72QwmdFAzbstARDkpFN9ZysM+OwNQfqk8XAnJUm4/i0KykQ4wniDC8+igymA+DPN4EwOamk5YtmfS2UhckZTcvXIhT3eeDyxmKookhyqZxRWckF0u02ir9zex8SSfo0yF+TC1wyG4eOjRYd1tbQQFKZUUScqtRqg945reA2DS6mfssghMR6fXgsGmb0GpfJjis6TK7eWgXVuN0kp233psjRalQ1H4ZjM6TOf4cAbjSc4W1SYaH4bZWsOAhiaf1Nt0EmUiFPOxHxUcl6v6XLWdYPBQL5d1Pkzx/uQQNq6Zr7bMcUhXtPP4gLHXnwA6M0DB4NTzot6E4AOKxoMZlVDycDrsskfUYXzAYlf9/otJTGcmuDlbJZsY+DCJx4eP1AAVnHp5hLbsID75kBkNkyhu3f/zJmCTTEI8my9rxiZGPmD76UPVhkAym/v6cS0Bu4l2BB9uIESQYdy+2tbzg7VJyAZqJjj3bNBlamPmA1zx8YuZYFNTh8+mB8PYIaMqn+GPPpKPooCg8WGqg/Xj2ZeHm5NJlQ20nj/fr9k0svABNrT19aROKDiTnHrx8v6rOjAllQ+ddXSsySdxspk0aCY59/KoaNfIjg9Q7fkhiQg6W3BzmlH58DQeDQqwOp8XyeQkgWftYLpqdiytlT0fmPHumxAFdT4shfMMgeDzVXJyUgW0+WL2qBUcpg0foMTg8VdzSVs+9HkYx5r5TM7NHzx7VUu0bdaOD1S1/vzJi7lJVBoQfOgzIMHAB9CZOq5V27OBuooPkKtYHXwZNPGhzYDg2Qojn7nBq1tdiw/ULOIT1fnQZkDsx+aTNPGhy4A4K5+1fzOf5IyBD10GJHxsPjMWPjQZUID9Y3y4idh33HWKvSYfd5MP+//e60+nGMHHfU0+D7+/+/R7pKd3vx+4wltmk5iP2+Vu8qGoiGZ1Pm63G/KZas9n4Mu7S4SDTCx9991Au38A+SSno6BznY/wb9r5jy/Ohs9Uaz6BpbsDlg+/e+DuUmsjsuNDT4SONfm4zXwSPVY9+4vNQqC/zNosxFOTWVCQW/hQc0qe1fm4TXx8f03d+ePqT/01jP6DLR9aHIyz8plq8mm8Xv/jPa9vj7ThQ4uDxdrx8fc98F89DbNVovG674d2fCjJYEJ7Pn1/S4X/SLe+1Dd9PGE/kxY+dJSIAbY9H7bvx1TPh3fbk/qxTxA0PpN2fOgIQNxVfNi+jdTph/Z6mtoALdvzoSMAxax8vjbyYXl25AOj9HrjIWyo8Tmz50NFALLlM2fgwwrs60brg6wWubZfs3jKS/DZtPKhIgCxtnzmDHyAj33jtz2BYaeE/4F6VZ3OZ2qKUj4BOz5zc3PzRj5sX/26UTqc+lufmhOv4EPDHJ67Jp9rR2mYuJpdXsGHggA9YeHjtufD8g8bd67urz/1UB//reIDQu729lVRen2EJe4taPLZtOdDQQKLXZ8PK/APGm2jNJhSsIY7Va/gQ8EU/kP4sAKYbPha9+Xzf2PYvBP46B/3NfiwbScbZGS+Hh8KEvwH8mmTxvCUotP4EIMx8FlowQemMdvJxp3GQ968bZPPVCfwyStg/0XEZ36tlf3AWzNej1gOCbm2t1nz3aqk/czNIT6iGM3s0MqHlQMAj+j2Ij7oIl47PsCELJONYuOB+bZTks9PU4iPCPms0sqH5aUE/ITd0ZO1+fn5rQCQPR8BTDYMx8yIKYWZD+yF+Qk47BywHxHwiZep5SOn4QjE6AXkM/sl0M+2fEAJ2CCjdE8KH86w8vnhZ9jLl2jCexRFnccL1PO5BHzeoPva7e0H5LBfqv5+rYt+f/UXc+7iYxMTsRjfQGbmhgF/rY755OjiQ7gFr6h8ziGf53CtbXyGNVB3N7e9jXtYH+G6uw0eFutmXK6EL+FifCiQF/8OC4Ya5hNaouqmS+JWUz6XxUM4fjM/v3YG19rxAdG52s1xXPedBhh9YmSdg38Umwd9wKB77vj9je2Gv9GP7Ke2AAuGMO5cHtD5UFA/k3zuRfAQtgCf+RO41soHZPcGB/EAJr+kfMXUF+ofnJrhOSbcaJwW0Z0JvlP/Nsh0g28An78XkXEmZKIOoGB+Stzozu+sYj6Du4CPAl3DwgdWh5ym7loKeFrzrzv+h31CAIQjcgZyCuYjiM9PCdi3e0UhqkgK+BDPSeALccTH7RsHfHZrjJUPjMxNIABJtUr+9UvqxwCzbaquE41+5una3Nx9zD6bI/hQcPyH4AMmGCKS5wTweQNvczPxgQdZCSBmddd6mHUVTzqyuqgOf+SU+XZt7Rjzidwj+NzYqK+vAMEnLyMfEN3ngM/8OWPmw3+TqrbBAwAxp2pSy+6V4iH1EYkuf0/szRs1vZPlIQ18DAm+tIIT/DQM0BeMkY/Avh5Jt8XDMcUUnplxe/AZXPES/he+FPN0IYy6FkMDVKV3+wRWgwF6tGo8Pk9GZnsFmHW1ql4MoTft6dDrp7ET7LppiXwO4A0N+YNEJrBCBfERizAA7W4Zzu8YI7O9+SRSaqcZ/EhWRX28eMLPvMI9Z0t0pS9TgJbxKKJnagDSzw+2j8wqnx4td5n4MA0f9q7o/jBd6csQoFlBToui1ytGj6CDnSSafPquisyqe2mVz76JT/8p4wX9imKFmH3Rcf2GIUAvR6JeOJDw2PwCdDDMR2C3R7gr8QA+2/ioR7akyCUoSSnhCHR6h0H9JqQ8ZeHZFIByiI83ejG/sDB/hvnwV0dmlY969icez2oq4Qe6AcdDfAzVIRXhxxiAWKkoIj5Hu4DPWBVdH3WNyIz5uPy4xzi6RRkVPxXMx7eN+EQrZdrCD2M8BFRZRHzEorKwsLB7XPT3oaMZ18ED7QdXP4hPfA+iyWE+YdV+KHQvYwVUjmMHE38FBrRwEvZfKzJrfNT4g/hk0OPuVD44/lCY3aEMUwwpgQ2oNg74LPyj8eAHrvu6gmkKCvFJS9B/VD4gsUH3om5ygUVmsDjOYF7vGeRz8c/UF0b193/RUu5wA/WH+GQVGIBUPqmiGzqtxFLoXoYMJiwpagarQwdb+J/TfqN++62/paqMH52dj+uPkMDxuQeF52ikQqN7GUtEXtkQsQFdQD4hywUt5eUW0yZuuMCcogI6XsqsrmYy8EVBfBphCF0MLVFXHGKREXonThrQ7rFl4/Tw8ENrF+nhZehPDVhBr8R1wYWnyHzEjRLhyFTMTTWREZqVqtiAPMiAlKp18/TOQdmA6GF5eQcf6wmnrBcIhf0JlwcAz9FY/GAJVgPyiLUxaEBntg1WysvLO+XC0lKhvLO8XF5pDrfHcoFQGCwBeMQVWaDqzAUpY4qvej1AXvEcedhWq0bplZXszsqK6QuuwqYLhE79RQb1VqEzuWOZIxAEJPpk6GHv211St2xdVGxs6yYUbmy7GC/Es0Gx+VgjEOTjib7abe1huJkNH+Bj/kZ/T0+4p+eOvxFmXMgYo6UypckLy2BAFczH23W5MDq6sPu4ZSt7PmA+erq+PbK93lNkEsgUPWJWoeu8oFkGA1KyGJAYVkaB7HKY2qoFH7ySy3957lGl0HdgzCjyROGSrI4qerQL+LQOQa35bL3dBVJ8qqfuV6jN7ZpID4tnohiQeAYB7Z61en5UKz6DsDZYGK/jbrxVKg9sGGWX4z3e4jvoYbu/tmjTgk8xtICKb5VyNLdDuXdBkQdayyXVw8QaCkFvrfMMqBZ8iicIz6XmpZES9d4FZbgWSPOwaP0tAmRbJtrzSfyE5v4nPq/mXXRd89NSxMXieWnDqwI6fjs6Pjo6ZgfIlo/rbHdhFMzcaqJqPyW6LlltLSIE8QU5oQ7Pe747Pj4+KtkAsuOTQCF9YayuGeBqrgOCDxaZ5IcrWu3SdQYBjctWQDZ8XAgP8EcNT1Ymche9wQeLuB1MKGkhyNN7MW4PyMonoeI50toWyS+Wo7BwNokAlJfUMhpkeQxIMmcxC5/iBcbzSsOTUMqdhIdMYvzSnloFNQGNmeogM5/qyagRjzdHXC9Gc+rSRQAqy0UtBgFAY2Nj42/PDLemmPgMhlQ8WuaCsVnoLDwGQMMKDM9Qnt6zMajxd+Rk1cjnsTSKEh2IPbBFl0fcV4SOw2MAdK/kUcfq6T1/iwC9J6J0gPhqavf5W+iCo/JWtAsxBXUzkbo6Bw8RpAW+UlENCBD6VUYmJP/anK0SfKo4Qo2/H4zi7buii5L+fY2dEJp1cbaAvEcY0NiF5mO6fx1JGM+7sIbHk5UGmo+y6Sw8JCAhF28Cig6+x4Bk9ZCiZj/FM1kN3z6vbj3NwqcDv2BPf+wWn6t0qYC6xPCF6mOXyIRUPlsY27h87GluuahbD9Vzrpaa0F0s1wTk6T2WsAn969it8qleqm73rh5t4onoeDrNtzRp3yMn8PFSQht4l6eOjEUZk3+vM0ycSRxrPnfpE7WNovuyhqeDvyBWMyEB1EHFJiCvD9iLoihjY9JlNa66FsDzqulbXV2rIS1zdarxYGlf3s2XpQ3dgjxH7yEggEh+h1CBXy6beQusr+TUkzmdVPTYK4DtgC/sLermIYbPJJUQehl7/6pXx1cM3cNVcye7li4OjZUfUFZ1QB5P/XdZUTUmn+uRp8uzIe2gOdftoAPFQS/j2UquSBDqffUeE5Ive7zE8ggue24PHajABIzSO9JGM8gAEr7jf8mK9Hu9l6CTqJRAZBYmbhUdJC4m8AUp06XDAJns+H97yAXAt4Z5/hbCweIm8rlQleDR5fGQdHpXpUJ3Zyf0qxTY34sAJL1dvb3wpYt48VRDudsNByldKgETglAwGPwGlNlbvLr1bdD+3j7wJaQu9Q1EHqWSvrrp7VA6J2c9KhqEx1Os7GWvbnd7lJVLG11dTTqre5nbmrNaKBCRKxvQhgCdjLTquJZVESlX9XgSDp2WWpQrP+85dForEHHoOHLkyJEjR44cOXLkyJEjR44cOXLkiBL9H08+INzbTr7gAAAAAElFTkSuQmCC" 
              alt=""
            />
            <h2>{displayText}</h2>
          </div>
        </Link>
        <ul>
          <Link to="/About">
            <li>About</li>
          </Link>
          <Link to="/Services">
            <li>Services</li>
          </Link>
          <Link to="/Test">
            <li>Test</li>
          </Link>
        </ul>
      </nav>
    </div>
  );
}

import React, { useState } from 'react';
import axios from 'axios';
import './test.css';
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';

const API_BASE_URL = 'http://172.16.40.174:5000';

export default function Test() {
  const [url, setUrl] = useState('');
  const [reportUrl, setReportUrl] = useState('');
  const [loading, setLoading] = useState(false);
  const [reportLoading, setReportLoading] = useState(false);
  const [showReportBox, setShowReportBox] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!url) {
      toast.error('Please enter a valid URL!');
      return;
    }

    setLoading(true);
    try {
      const response = await axios.post(
        `${API_BASE_URL}/predict`,
        { message: url },
        { headers: { 'Content-Type': 'application/json' } }
      );

      if (response.status === 200) {
        if (response.data.prediction === 'Spam') {
          toast.error('⚠️ Threat Detected: This link appears malicious!');
        } else {
          toast.success('✅ This link appears safe.');
          setShowReportBox(true); // Show report option if marked safe
        }
      }
    } catch (error) {
      // ... (keep your existing error handling)
    } finally {
      setLoading(false);
      setUrl('');
    }
  };

  const handleReportSubmit = async (e) => {
    e.preventDefault();
    if (!reportUrl) {
      toast.error('Please enter a URL to report!');
      return;
    }

    setReportLoading(true);
    try {
      await axios.post(
        `${API_BASE_URL}/report`,
        { url: reportUrl, reportedAs: 'malicious' },
        { headers: { 'Content-Type': 'application/json' } }
      );
      toast.success('🚨 Thank you for reporting! Our team will review this URL.');
      setReportUrl('');
      setShowReportBox(false);
    } catch (error) {
      toast.error('Failed to submit report. Please try again later.');
    } finally {
      setReportLoading(false);
    }
  };

  return (
    <div className="testcontain">
      <div className="form-container">
        <ToastContainer position="top-center" />
        
        {/* Main Scanner Card */}
        <div className="scanner-card">
          <h2>🔍 Link Threat Scanner</h2>
          <form onSubmit={handleSubmit}>
            <input
              type="url"
              value={url}
              placeholder="Enter a URL to scan..."
              onChange={(e) => setUrl(e.target.value)}
              required
              disabled={loading}
            />
            <button type="submit" disabled={loading}>
              {loading ? 'Scanning...' : 'Scan Now'}
            </button>
          </form>
        </div>

        {/* Report Box (appears conditionally) */}
        {showReportBox && (
          <div className="report-sidebox">
            <h3>⚠️ False Negative?</h3>
            <p>If you believe this URL is malicious despite our scan, please report it:</p>
            <form onSubmit={handleReportSubmit}>
              <input
                type="url"
                value={reportUrl}
                placeholder="Enter suspicious URL..."
                onChange={(e) => setReportUrl(e.target.value)}
                required
                disabled={reportLoading}
              />
              <div className="report-buttons">
                <button type="submit" disabled={reportLoading}>
                  {reportLoading ? 'Reporting...' : 'Submit Report'}
                </button>
                <button 
                  type="button" 
                  onClick={() => setShowReportBox(false)}
                  className="cancel-btn"
                >
                  Cancel
                </button>
              </div>
            </form>
          </div>
        )}

        {/* Info Card */}
        <div className="info-card">
          <h3>🔐 How It Works</h3>
          <p>We scan URLs using AI models and threat intelligence to detect phishing, malware, or scam links.</p>
          <ul>
            <li>Real-time scanning</li>
            <li>ML-trained pattern recognition</li>
            <li>Community reporting system</li>
          </ul>
        </div>
      </div>
    </div>
  );
}
document.getElementById("readUrlBtn").addEventListener("click", () => {
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
        const url = tabs[0].url;
        document.getElementById("urlOutput").textContent = `Current URL: ${url}`;

        fetch("http://localhost:5000/api/url-scan", {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify({ url })
        })
            .then(response => response.json())
            .then(data => {
                document.getElementById("apiResponse").textContent = `API Response: ${JSON.stringify(data)}`;
            })
            .catch(error => {
                document.getElementById("apiResponse").textContent = `Error: ${error.message}`;
            });
    });
});
